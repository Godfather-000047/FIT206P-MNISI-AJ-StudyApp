
fetch('data/notes.json')
  .then(response => response.json())
  .then(data => {
    const searchBar = document.getElementById('searchBar');
    const results = document.getElementById('results');
    searchBar.addEventListener('input', () => {
      const term = searchBar.value.toLowerCase();
      results.innerHTML = '';
      data.filter(entry => entry.text.toLowerCase().includes(term))
          .forEach(entry => {
              const div = document.createElement('div');
              div.innerHTML = `<p>${entry.text}</p>`;
              results.appendChild(div);
          });
    });
  });
