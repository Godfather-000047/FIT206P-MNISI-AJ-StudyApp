
const quizData = [
  {
    question: "What is a user-defined subroutine?",
    options: [
      "A built-in function in Delphi",
      "A function created by the user",
      "A component",
      "An error handler"
    ],
    answer: 1
  }
];

let score = 0;
let current = 0;

const successAudio = new Audio('assets/music/success.mp3');
const failAudio = new Audio('assets/music/fail.mp3');

function showMessage(msg) {
  const bubble = document.getElementById("speech-bubble");
  bubble.innerText = msg;
  bubble.style.display = "block";
  setTimeout(() => { bubble.style.display = "none"; }, 2000);
}

function animateAvatar() {
  const avatar = document.getElementById("avatar");
  avatar.classList.add("avatar-bounce");
  setTimeout(() => avatar.classList.remove("avatar-bounce"), 500);
}

function showQuiz() {
  const container = document.getElementById("quizContainer");
  container.innerHTML = "";
  if (current >= quizData.length) {
    container.innerHTML = `<h2>Your score: ${score}/${quizData.length}</h2>`;
    showMessage("Quiz complete!");
    animateAvatar();
    return;
  }

  const q = quizData[current];
  const qBlock = document.createElement("div");
  qBlock.innerHTML = `<h3>${q.question}</h3>`;
  q.options.forEach((opt, idx) => {
    const btn = document.createElement("button");
    btn.textContent = opt;
    btn.onclick = () => {
      if (idx === q.answer) {
        btn.style.background = "green";
        showMessage("Great job!");
        successAudio.play();
        score++;
      } else {
        btn.style.background = "red";
        showMessage("Oops, try again!");
        failAudio.play();
      }
      animateAvatar();
      current++;
      setTimeout(showQuiz, 1000);
    };
    qBlock.appendChild(btn);
  });
  container.appendChild(qBlock);
}

window.onload = showQuiz;
