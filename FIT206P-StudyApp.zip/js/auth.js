
function checkLogin() {
  if (!localStorage.getItem("loggedIn")) {
    window.location.href = "login.html";
  }
}

function logout() {
  localStorage.removeItem("loggedIn");
  window.location.href = "login.html";
}

function signup() {
  const username = document.getElementById("signupUsername").value;
  const password = document.getElementById("signupPassword").value;
  if (username && password) {
    localStorage.setItem("user", JSON.stringify({ username, password }));
    const msg = document.getElementById("signupMessage");
    msg.textContent = "Account created successfully!";
    msg.style.color = "green";
    setTimeout(() => window.location.href = "login.html", 2000);
  }
}

function login() {
  const username = document.getElementById("loginUsername").value;
  const password = document.getElementById("loginPassword").value;
  const stored = JSON.parse(localStorage.getItem("user"));
  if (stored && stored.username === username && stored.password === password) {
    localStorage.setItem("loggedIn", "true");
    window.location.href = "index.html";
  } else {
    const msg = document.getElementById("loginMessage");
    msg.textContent = "Invalid credentials";
    msg.style.color = "red";
  }
}
